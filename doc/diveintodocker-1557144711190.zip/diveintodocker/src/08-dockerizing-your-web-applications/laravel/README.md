# Laravel

This Laravel project is the result of generating a new project. It is untouched.

It is on you to integrate PostgreSQL, Redis, etc..
