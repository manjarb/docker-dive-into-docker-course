# -*- coding: utf-8 -*-

bind = '0.0.0.0:5000'
accesslog = '-'
