using System;

namespace Hello
{
    public class Program
    {
        public static int Main(string[] args)
        {
            Console.WriteLine($"Hello World!");
            return 0;
        }
    }
}
